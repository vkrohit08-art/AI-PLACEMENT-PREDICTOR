const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user || user.role !== 'admin') return Response.json({ error: 'TPO only' }, { status: 403 });

    const body = await req.json();
    const { logId } = body || {};
    if (!logId) return Response.json({ error: 'logId required' }, { status: 400 });

    const log = await db.asServiceRole.entities.EmailLog.get(logId);
    if (!log) return Response.json({ error: 'Log not found' }, { status: 404 });

    const html = `<div style="font-family:Inter,Arial,sans-serif;max-width:600px;margin:auto;color:#0F172A">
      <div style="background:#0F172A;padding:20px;border-radius:8px 8px 0 0"><h2 style="color:#fff;margin:0">Training &amp; Placement Office</h2></div>
      <div style="padding:24px;border:1px solid #E2E8F0;border-top:none;border-radius:0 0 8px 8px">
        <p>Dear ${log.student_name || "Student"},</p>
        <p>This is a re-delivery of your placement notification regarding <strong>${log.company || "a company opportunity"}</strong>.</p>
        <p style="color:#475569">Subject: ${log.subject}</p>
        <p>Please check with the TPO office for details.</p>
        <p style="color:#475569">Regards,<br/>Training &amp; Placement Office</p>
      </div></div>`;

    let status = "Sent";
    let errorMsg = "";
    try {
      await db.asServiceRole.integrations.Core.SendEmail({ to: log.to_email, subject: log.subject, html });
    } catch (e) {
      status = "Failed";
      errorMsg = e.message;
    }
    await db.asServiceRole.entities.EmailLog.update(logId, { status, error: errorMsg });
    return Response.json({ status });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}