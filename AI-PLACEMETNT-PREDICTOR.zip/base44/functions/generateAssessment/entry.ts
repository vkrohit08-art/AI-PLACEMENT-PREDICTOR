const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const SCHEMA = {
  type: "object",
  properties: {
    questions: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "number" },
          level: { type: "string", enum: ["Easy", "Intermediate", "Hard"] },
          topic: { type: "string" },
          question: { type: "string" },
          type: { type: "string", enum: ["mcq", "code"] },
          options: { type: "array", items: { type: "string" } },
          correct_answer: { type: "string" },
          explanation: { type: "string" },
          credits: { type: "number" }
        },
        required: ["id", "level", "topic", "question", "type", "correct_answer", "credits"]
      }
    }
  },
  required: ["questions"]
};

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const language = body?.language;
    if (!language) return Response.json({ error: 'Language is required' }, { status: 400 });

    const prompt = `You are an expert technical assessor for engineering placements.
Generate exactly 10 unique assessment questions for the programming language "${language}".
Distribution MUST be: 5 Easy (MCQ, 3 credits each), 3 Intermediate (MCQ, 6 credits each), 2 Hard (short coding problems, 8.5 credits each).
Easy MCQ topics: syntax, variables, data types, operators, basic functions, basic loops, conditions, simple output prediction.
Intermediate MCQ topics: logical reasoning, debugging, data structures, functions, control flow, output prediction, basic algorithms, problem solving.
Hard questions: short coding problems the student writes code for — keep them simple, unique, and language-relevant. For code questions, "options" should be an empty array and "correct_answer" should be a reference solution or key concept.
Randomize question content so different students get different questions. Make questions clear and unambiguous.
Return JSON with a "questions" array.`;

    const result = await db.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: SCHEMA,
      model: "gemini_3_flash"
    });

    return Response.json({ questions: result.questions || [] });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}