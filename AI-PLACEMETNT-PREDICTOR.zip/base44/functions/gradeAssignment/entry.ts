const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from 'npm:@base44/sdk@0.8.44';

const SCHEMA = {
  type: "object",
  properties: {
    grade: { type: "number" },
    feedback: { type: "string" },
    strengths: { type: "array", items: { type: "string" } },
    improvements: { type: "array", items: { type: "string" } }
  },
  required: ["grade", "feedback"]
};

export default async function(req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json();
    const assignmentId = body?.assignmentId;
    const submission = body?.submission;
    if (!assignmentId || !submission) return Response.json({ error: 'assignmentId and submission are required' }, { status: 400 });

    const assignment = await db.entities.Assignment.get(assignmentId);
    if (!assignment) return Response.json({ error: 'Assignment not found' }, { status: 404 });

    const prompt = `You are an expert technical evaluator grading a student's coding assignment.

ASSIGNMENT:
Title: ${assignment.title}
Language/Skill: ${assignment.skill}
Difficulty: ${assignment.difficulty}
Problem: ${assignment.description}
Evaluation criteria: ${assignment.evaluation_criteria || "Correctness and code quality"}
Reference solution (for comparison only): ${assignment.expected_solution || "N/A"}

STUDENT SUBMISSION:
${submission}

Grade the submission 0-100 based on correctness, edge-case handling, efficiency, and code quality.
Return ONLY the JSON schema with:
- "grade": number 0-100
- "feedback": 2-4 sentences of constructive feedback explaining the grade.
- "strengths": 1-3 things done well.
- "improvements": 1-3 specific suggestions to improve.`;

    const result = await db.asServiceRole.integrations.Core.InvokeLLM({
      prompt,
      response_json_schema: SCHEMA,
      model: "gemini_3_flash"
    });

    const updated = await db.entities.Assignment.update(assignmentId, {
      submission,
      status: "Graded",
      grade: result.grade,
      feedback: result.feedback,
      submitted_at: new Date().toISOString(),
      graded_at: new Date().toISOString()
    });

    return Response.json(updated);
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}