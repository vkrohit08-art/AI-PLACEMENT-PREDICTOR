// Shared company-matching + scoring helpers used by frontend and backend.

export const PROGRAMMING_LANGUAGES = ["Python", "Java", "C++", "JavaScript/TypeScript", "SQL", "Go", "C#", "Other"];

export function proficiencyFromPercentage(pct) {
  if (pct >= 85) return "Strong";
  if (pct >= 70) return "Advanced";
  if (pct >= 50) return "Intermediate";
  if (pct >= 30) return "Developing";
  return "Beginner";
}

export function readinessCategory(prob) {
  if (prob >= 80) return "Highly Ready";
  if (prob >= 60) return "Placement Ready";
  if (prob >= 40) return "Needs Improvement";
  return "High Risk";
}

// Compute match percent between student skill set and company requirements.
export function computeMatch(studentSkills, companySkills) {
  const want = (companySkills || []).map((s) => s.toLowerCase().trim());
  const have = (studentSkills || []).map((s) => s.toLowerCase().trim());
  if (want.length === 0) return { percent: 0, matched: [], missing: [] };
  const matched = want.filter((s) => have.some((h) => h.includes(s) || s.includes(h)));
  const missing = want.filter((s) => !matched.includes(s));
  return {
    percent: Math.round((matched.length / want.length) * 100),
    matched: companySkills.filter((s) => matched.includes(s.toLowerCase().trim())),
    missing: companySkills.filter((s) => missing.includes(s.toLowerCase().trim())),
  };
}

// Aggregate a student's technical skill set from profile + assessment languages.
export function studentSkillSet(profile, attempts = []) {
  const skills = new Set();
  (profile?.programming_languages || []).forEach((l) => skills.add(l));
  (profile?.projects || []).forEach((p) => (p.technologies || []).forEach((t) => skills.add(t)));
  (profile?.certifications || []).forEach((c) => c.skill && skills.add(c.skill));
  attempts.forEach((a) => a.language && skills.add(a.language));
  if (profile?.other_languages) skills.add(profile.other_languages);
  return Array.from(skills);
}