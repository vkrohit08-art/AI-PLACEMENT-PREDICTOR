const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/lib/AuthContext";

export function useStudentData() {
  const { user } = useAuth();
  const [data, setData] = useState({
    profile: null, attempts: [], prediction: null, roadmap: null, matches: [], loading: true
  });

  const load = useCallback(async () => {
    if (!user?.id) return;
    try {
      const [profiles, attempts, predictions, roadmaps, matches] = await Promise.all([
        db.entities.StudentProfile.filter({ created_by_id: user.id }, "-created_date", 1),
        db.entities.AssessmentAttempt.filter({ created_by_id: user.id, status: "completed" }, "-completed_at", 50),
        db.entities.PlacementPrediction.filter({ created_by_id: user.id }, "-created_date", 1),
        db.entities.Roadmap.filter({ created_by_id: user.id, status: "Active" }, "-created_date", 1),
        db.entities.CompanyMatch.filter({ created_by_id: user.id }, "-created_date", 50),
      ]);
      setData({
        profile: profiles[0] || null,
        attempts: attempts || [],
        prediction: predictions[0] || null,
        roadmap: roadmaps[0] || null,
        matches: matches || [],
        loading: false,
      });
    } catch (e) {
      setData((d) => ({ ...d, loading: false }));
    }
  }, [user?.id]);

  useEffect(() => { load(); }, [load]);
  return { ...data, reload: load };
}