const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { Outlet, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import {
  LayoutDashboard, ClipboardCheck, Map, Building2, User, Users,
  Mail, GraduationCap, LogOut, ShieldAlert, BarChart3, Briefcase,
  FileCode2, ClipboardList
} from "lucide-react";

const studentNav = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/profile", label: "Profile", icon: User },
  { to: "/assessment", label: "Assess", icon: ClipboardCheck },
  { to: "/prediction", label: "Prediction", icon: BarChart3 },
  { to: "/roadmap", label: "Roadmap", icon: Map },
  { to: "/companies", label: "Matches", icon: Building2 },
  { to: "/assignments", label: "Assignments", icon: FileCode2 },
];

const tpoNav = [
  { to: "/tpo", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/tpo/students", label: "Students", icon: Users },
  { to: "/tpo/companies", label: "Companies", icon: Briefcase },
  { to: "/tpo/assignments", label: "Assignments", icon: ClipboardList },
  { to: "/tpo/emails", label: "Emails", icon: Mail },
];

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const isTpo = user?.role === "admin";
  const nav = isTpo ? tpoNav : studentNav;
  const [profile, setProfile] = useState(null);

  useEffect(() => {
    if (!isTpo) {
      db.entities.StudentProfile.filter({ created_by_id: user?.id }, "-created_date", 1)
        .then((r) => setProfile(r[0] || null))
        .catch(() => setProfile(null));
    }
  }, [user?.id, isTpo]);

  const handleLogout = async () => {
    await logout();
    navigate("/login");
  };

  return (
    <div className="min-h-screen bg-[hsl(210_40%_98%)]">
      {/* Desktop sidebar */}
      <aside className="hidden md:flex fixed inset-y-0 left-0 w-60 flex-col bg-[hsl(222_47%_11%)] text-slate-200 z-30">
        <div className="px-5 py-5 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-lg bg-[hsl(217_91%_60%)] flex items-center justify-center">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <p className="font-display font-bold text-white text-sm leading-tight">Placement AI</p>
              <p className="text-[0.65rem] text-slate-400 uppercase tracking-wider">Employability Intel</p>
            </div>
          </div>
        </div>

        <div className="px-3 py-3">
          <span className="text-[0.65rem] font-semibold uppercase tracking-wider text-slate-500 px-2">
            {isTpo ? "TPO / Admin" : "Student"}
          </span>
        </div>

        <nav className="flex-1 px-3 space-y-1">
          {nav.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `flex items-center gap-3 px-3 py-2.5 rounded-md text-sm font-medium transition ${
                  isActive ? "bg-[hsl(217_91%_60%)] text-white" : "text-slate-300 hover:bg-white/5 hover:text-white"
                }`
              }
            >
              <item.icon className="w-4 h-4" />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="p-3 border-t border-white/10">
          {!isTpo && profile && (
            <div className="px-3 py-2 mb-2 rounded-md bg-white/5">
              <p className="text-xs text-slate-400">Email sync</p>
              <p className="text-xs text-emerald-400 font-medium flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" /> Verified
              </p>
            </div>
          )}
          <button onClick={handleLogout} className="flex items-center gap-3 px-3 py-2.5 rounded-md text-sm text-slate-300 hover:bg-white/5 hover:text-white w-full">
            <LogOut className="w-4 h-4" /> Sign out
          </button>
        </div>
      </aside>

      {/* Mobile top bar */}
      <header className="md:hidden sticky top-0 z-30 flex items-center justify-between px-4 h-14 bg-[hsl(222_47%_11%)] text-white">
        <div className="flex items-center gap-2">
          <GraduationCap className="w-5 h-5 text-[hsl(217_91%_60%)]" />
          <span className="font-display font-bold text-sm">Placement AI</span>
        </div>
        <span className="text-[0.65rem] font-semibold uppercase tracking-wider bg-white/10 px-2 py-1 rounded">
          {isTpo ? "TPO" : "Student"}
        </span>
      </header>

      <main className="md:ml-60 pb-20 md:pb-0">
        <div className="max-w-[1600px] mx-auto p-4 md:p-6">
          <Outlet />
        </div>
      </main>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t border-[hsl(214_32%_91%)] flex h-16">
        {nav.slice(0, 5).map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              `flex-1 flex flex-col items-center justify-center gap-0.5 text-[0.6rem] font-semibold ${
                isActive ? "text-[hsl(217_91%_60%)]" : "text-slate-400"
              }`
            }
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </NavLink>
        ))}
      </nav>
    </div>
  );
}