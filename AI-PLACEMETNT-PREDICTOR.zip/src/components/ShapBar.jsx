import React from "react";

export default function ShapBar({ factor, contribution }) {
  const positive = contribution >= 0;
  const width = Math.min(Math.abs(contribution) * 4, 100);
  return (
    <div className="flex items-center gap-2 py-1">
      <span className="w-28 shrink-0 truncate text-xs font-medium text-slate-600">{factor}</span>
      <div className="relative flex-1 h-3 rounded-sm bg-slate-100 overflow-hidden">
        <div
          className="absolute top-0 h-full rounded-sm"
          style={{
            width: `${width}%`,
            backgroundColor: positive ? "hsl(173 80% 40%)" : "hsl(0 84% 60%)",
          }}
        />
      </div>
      <span className={`w-10 text-right text-xs font-bold ${positive ? "text-teal-600" : "text-rose-500"}`}>
        {positive ? "+" : "-"}
        {Math.abs(contribution)}%
      </span>
    </div>
  );
}