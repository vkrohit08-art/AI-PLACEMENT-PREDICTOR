const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { computeMatch, studentSkillSet } from "@/lib/employability";
import { Building2, Plus, Trash2, Mail, X, Check } from "lucide-react";

export default function TpoCompanies() {
  const { toast } = useToast();
  const [companies, setCompanies] = useState([]);
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [matchView, setMatchView] = useState(null); // company being matched
  const [sending, setSending] = useState(null);

  const load = async () => {
    setLoading(true);
    try {
      const [c, p, a] = await Promise.all([
        db.entities.Company.list(200),
        db.entities.StudentProfile.list(500),
        db.entities.AssessmentAttempt.filter({ status: "completed" }, "-completed_at", 500),
      ]);
      setCompanies(c || []);
      const attemptsByUser = {};
      (a || []).forEach((att) => { (attemptsByUser[att.created_by_id] = attemptsByUser[att.created_by_id] || []).push(att); });
      setStudents(p.map((prof) => ({ profile: prof, skills: studentSkillSet(prof, attemptsByUser[prof.created_by_id] || []) })));
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, []);

  const selectStudent = async (student, company) => {
    setSending(student.profile.id);
    try {
      const res = await db.functions.invoke("selectStudentForCompany", {
        studentId: student.profile.id,
        studentName: student.profile.full_name,
        studentEmail: student.profile.email,
        companyName: company.name,
        role: company.industry || "Engineering Role",
        matchPercent: computeMatch(student.skills, company.skills).percent,
      });
      if (res.data?.error) throw new Error(res.data.error);
      await db.entities.Selection.create({
        student_id: student.profile.id,
        student_name: student.profile.full_name,
        student_email: student.profile.email,
        company_id: company.id,
        company_name: company.name,
        role: company.industry || "Engineering Role",
        match_percent: computeMatch(student.skills, company.skills).percent,
        status: "Selected",
        email_sent: true,
      });
      toast({ title: "Email sent", description: `${student.profile.full_name} notified about ${company.name}.` });
    } catch (e) {
      toast({ title: "Selection failed", description: e.message, variant: "destructive" });
    } finally {
      setSending(null);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(217_91%_60%)] rounded-full animate-spin" /></div>;

  if (matchView) {
    const company = matchView;
    const ranked = students.map((s) => ({ ...s, match: computeMatch(s.skills, company.skills) }))
      .filter((s) => s.profile.email)
      .sort((a, b) => b.match.percent - a.match.percent);
    return (
      <div className="space-y-4">
        <button onClick={() => setMatchView(null)} className="text-sm text-slate-500 flex items-center gap-1"><X className="w-4 h-4" /> Close matching</button>
        <h1 className="font-display text-xl font-bold">{company.name} — Student Matching</h1>
        <p className="text-xs text-slate-500">Required: {(company.skills || []).join(", ")}</p>
        <div className="space-y-2">
          {ranked.map((s) => (
            <div key={s.profile.id} className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-3 flex items-center justify-between">
              <div>
                <p className="font-medium text-sm">{s.profile.full_name} <span className="text-xs text-slate-400">{s.profile.department}</span></p>
                <p className="text-xs text-slate-500">Matched: {s.match.matched.join(", ") || "—"} · Missing: {s.match.missing.join(", ") || "none"}</p>
              </div>
              <div className="flex items-center gap-3">
                <span className={`font-bold ${s.match.percent >= 70 ? "text-teal-600" : s.match.percent >= 40 ? "text-amber-600" : "text-rose-500"}`}>{s.match.percent}%</span>
                <Button size="sm" onClick={() => selectStudent(s, company)} disabled={sending === s.profile.id} className="bg-[hsl(217_91%_60%)]">
                  <Mail className="w-3.5 h-3.5 mr-1" /> {sending === s.profile.id ? "Sending..." : "Select & Email"}
                </Button>
              </div>
            </div>
          ))}
          {!ranked.length && <p className="text-sm text-slate-400">No students with verified email.</p>}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold text-[hsl(222_47%_11%)]">Companies</h1>
        <Button onClick={() => { setEditing(null); setShowForm(true); }} className="bg-[hsl(217_91%_60%)]"><Plus className="w-4 h-4 mr-1" /> Add Company</Button>
      </div>

      {showForm && <CompanyForm editing={editing} onSaved={() => { setShowForm(false); load(); }} onCancel={() => setShowForm(false)} />}

      <div className="space-y-3">
        {companies.map((c) => (
          <div key={c.id} className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-display font-bold text-[hsl(222_47%_11%)]">{c.name}</h3>
                <p className="text-xs text-slate-500">{c.industry} · {c.location}</p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {(c.skills || []).map((s, i) => <span key={i} className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded">{s}</span>)}
                </div>
              </div>
              <div className="flex gap-2">
                <Button size="sm" variant="outline" onClick={() => setMatchView(c)}>Match Students</Button>
                <Button size="sm" variant="ghost" onClick={() => { setEditing(c); setShowForm(true); }}>Edit</Button>
                <Button size="sm" variant="ghost" onClick={async () => { if (confirm(`Delete ${c.name}?`)) { await db.entities.Company.delete(c.id); load(); } }}><Trash2 className="w-4 h-4 text-rose-500" /></Button>
              </div>
            </div>
          </div>
        ))}
        {!companies.length && <p className="text-sm text-slate-400">No companies yet. Add one or seed the starter set.</p>}
      </div>

      {!companies.length && (
        <Button variant="outline" onClick={seedCompanies}>Seed Starter Companies</Button>
      )}
    </div>
  );

  async function seedCompanies() {
    const starters = [
      { name: "Larsen & Toubro Technology Services — LTTS", industry: "Engineering Services", location: "India", skills: ["Python", "C/C++", "Embedded Systems", "AI/ML", "IoT", "CAD Tools", "Problem Solving"], max_active_backlogs: 0 },
      { name: "Tata Consulting Engineers — TCE", industry: "Consulting", location: "India", skills: ["Civil Fundamentals", "AutoCAD", "Project Management", "Sustainability"], max_active_backlogs: 1 },
      { name: "Tessolve Services Pvt. Ltd.", industry: "Semiconductor", location: "India", skills: ["VLSI Design", "Verilog/VHDL", "C/C++", "Python", "Debugging"], max_active_backlogs: 0 },
      { name: "Chakr Innovation", industry: "Cleantech", location: "India", skills: ["Environmental Engineering", "Product Design", "R&D", "Mechanical Prototyping"], max_active_backlogs: 1 },
      { name: "Karamtara Engineering", industry: "Power Systems", location: "India", skills: ["Power Systems", "Electrical Engineering", "Structural Design", "Project Execution"], max_active_backlogs: 1 },
      { name: "GreyOrange Robotics", industry: "Robotics", location: "India", skills: ["Robotics", "Automation", "AI/ML", "Python", "ROS", "Mechanical Design"], max_active_backlogs: 0 },
      { name: "Sedin Engineering", industry: "Mechanical Design", location: "India", skills: ["Mechanical Design", "3D Modeling", "SolidWorks", "CATIA", "Structural Analysis", "Project Management"], max_active_backlogs: 1 },
    ];
    await db.entities.Company.bulkCreate(starters);
    toast({ title: "Starter companies added" });
    load();
  }
}

function CompanyForm({ editing, onSaved, onCancel }) {
  const { toast } = useToast();
  const [form, setForm] = useState(editing || { name: "", description: "", industry: "", location: "", skills: [], min_cgpa: 0, max_active_backlogs: 0 });
  const [skillInput, setSkillInput] = useState("");

  const save = async () => {
    try {
      if (editing?.id) await db.entities.Company.update(editing.id, form);
      else await db.entities.Company.create(form);
      toast({ title: "Company saved" });
      onSaved();
    } catch (e) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5 space-y-3">
      <h2 className="font-display font-bold">{editing ? "Edit" : "Add"} Company</h2>
      <div className="grid md:grid-cols-2 gap-3">
        <Field label="Name"><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></Field>
        <Field label="Industry"><Input value={form.industry} onChange={(e) => setForm({ ...form, industry: e.target.value })} /></Field>
        <Field label="Location"><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></Field>
        <Field label="Max Active Backlogs"><Input type="number" value={form.max_active_backlogs} onChange={(e) => setForm({ ...form, max_active_backlogs: +e.target.value })} /></Field>
      </div>
      <Field label="Description"><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} rows={2} /></Field>
      <Field label="Required Skills">
        <div className="flex gap-2">
          <Input value={skillInput} onChange={(e) => setSkillInput(e.target.value)} placeholder="Type a skill and press Add" onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); if (skillInput.trim()) { setForm({ ...form, skills: [...form.skills, skillInput.trim()] }); setSkillInput(""); } } }} />
          <Button type="button" variant="outline" onClick={() => { if (skillInput.trim()) { setForm({ ...form, skills: [...form.skills, skillInput.trim()] }); setSkillInput(""); } }}>Add</Button>
        </div>
        <div className="flex flex-wrap gap-1 mt-2">
          {form.skills.map((s, i) => (
            <span key={i} className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded flex items-center gap-1">{s}<button onClick={() => setForm({ ...form, skills: form.skills.filter((_, idx) => idx !== i) })}><X className="w-3 h-3" /></button></span>
          ))}
        </div>
      </Field>
      <div className="flex gap-2 justify-end">
        <Button variant="outline" onClick={onCancel}>Cancel</Button>
        <Button onClick={save} className="bg-[hsl(217_91%_60%)]"><Check className="w-4 h-4 mr-1" /> Save</Button>
      </div>
    </div>
  );
}
function Field({ label, children }) {
  return <div><Label className="text-xs font-medium text-slate-600 mb-1 block">{label}</Label>{children}</div>;
}