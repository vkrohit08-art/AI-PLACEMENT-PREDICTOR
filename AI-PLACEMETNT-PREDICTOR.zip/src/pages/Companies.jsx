const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { Building2, Check, X, RefreshCw } from "lucide-react";

export default function Companies() {
  const { user } = useAuth();
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const m = await db.entities.CompanyMatch.filter({ created_by_id: user.id }, "-match_percent", 50);
      setMatches(m || []);
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => { load(); }, [user?.id]);

  if (loading) return <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(217_91%_60%)] rounded-full animate-spin" /></div>;

  if (!matches.length) {
    return (
      <div className="max-w-md mx-auto mt-12 bg-white border border-[hsl(214_32%_91%)] rounded-lg p-8 text-center">
        <Building2 className="w-10 h-10 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-slate-500">No company matches yet. Generate a placement prediction to get matched with companies.</p>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold text-[hsl(222_47%_11%)]">Company Matches</h1>
          <p className="text-sm text-slate-500">Your skills compared against company requirements.</p>
        </div>
        <button onClick={load} className="text-sm text-slate-500 flex items-center gap-1 hover:text-slate-700"><RefreshCw className="w-4 h-4" /> Refresh</button>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {matches.map((m) => (
          <div key={m.id} className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display font-bold text-[hsl(222_47%_11%)]">{m.company_name}</h3>
              <span className={`font-display text-2xl font-bold ${m.match_percent >= 70 ? "text-teal-600" : m.match_percent >= 40 ? "text-amber-600" : "text-rose-500"}`}>{m.match_percent}%</span>
            </div>
            {!m.eligible && <span className="inline-block text-[0.65rem] bg-rose-50 text-rose-600 px-2 py-0.5 rounded mb-3">Not eligible (backlogs)</span>}

            <div className="mb-3">
              <p className="text-[0.65rem] font-semibold uppercase tracking-wider text-teal-600 mb-1 flex items-center gap-1"><Check className="w-3 h-3" /> Matched</p>
              <div className="flex flex-wrap gap-1">
                {(m.matched_skills || []).map((s, i) => <span key={i} className="text-xs bg-teal-50 text-teal-700 px-2 py-0.5 rounded">{s}</span>)}
                {!m.matched_skills?.length && <span className="text-xs text-slate-400">None</span>}
              </div>
            </div>
            <div>
              <p className="text-[0.65rem] font-semibold uppercase tracking-wider text-rose-500 mb-1 flex items-center gap-1"><X className="w-3 h-3" /> Missing — focus your prep here</p>
              <div className="flex flex-wrap gap-1">
                {(m.missing_skills || []).map((s, i) => <span key={i} className="text-xs bg-rose-50 text-rose-600 px-2 py-0.5 rounded">{s}</span>)}
                {!m.missing_skills?.length && <span className="text-xs text-slate-400">None — full match!</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}