const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";

import ProbabilityRing from "@/components/ProbabilityRing";
import ShapBar from "@/components/ShapBar";
import { ArrowLeft, Award, BookOpen, FolderGit2, Mail } from "lucide-react";

export default function TpoStudentDetail() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const profile = await db.entities.StudentProfile.get(id);
        const [attempts, predictions, roadmaps, matches, selections] = await Promise.all([
          db.entities.AssessmentAttempt.filter({ created_by_id: profile.created_by_id, status: "completed" }, "-completed_at", 50),
          db.entities.PlacementPrediction.filter({ created_by_id: profile.created_by_id }, "-created_date", 1),
          db.entities.Roadmap.filter({ created_by_id: profile.created_by_id }, "-created_date", 5),
          db.entities.CompanyMatch.filter({ created_by_id: profile.created_by_id }, "-match_percent", 50),
          db.entities.Selection.filter({ student_id: id }, "-created_date", 50),
        ]);
        setData({ profile, attempts, prediction: predictions[0], roadmaps, matches, selections });
      } catch (e) {
        setData({ error: e.message });
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  if (loading) return <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(217_91%_60%)] rounded-full animate-spin" /></div>;
  if (data?.error) return <div className="p-8 text-center text-slate-500">{data.error}</div>;
  const p = data.profile;
  const pred = data.prediction;

  return (
    <div className="space-y-5">
      <Link to="/tpo/students" className="inline-flex items-center gap-1 text-sm text-slate-500 hover:text-slate-700"><ArrowLeft className="w-4 h-4" /> Back to students</Link>

      <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5 flex flex-col md:flex-row gap-5">
        <div className="flex items-center gap-4">
          {pred ? <ProbabilityRing value={pred.probability} size={120} label={pred.readiness_category} /> : <div className="w-[120px] h-[120px] rounded-full bg-slate-100 flex items-center justify-center text-xs text-slate-400">No prediction</div>}
          <div>
            <h1 className="font-display text-xl font-bold text-[hsl(222_47%_11%)]">{p.full_name}</h1>
            <p className="text-sm text-slate-500">{p.email}</p>
            <p className="text-xs text-slate-400">{p.department} · {p.branch} · Sem {p.semester}</p>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <Card title="Academic" icon={Award}>
          <Row k="10th" v={`${p.tenth_percentage || "—"}%`} />
          <Row k="12th" v={`${p.twelfth_percentage || "—"}%`} />
          <Row k="CGPA" v={p.current_cgpa || "—"} />
          <Row k="Active Backlogs" v={p.active_backlogs || 0} />
          <Row k="Total Backlogs" v={p.total_backlogs || 0} />
          {(p.backlog_history || []).map((b, i) => (
            <div key={i} className="text-xs text-slate-500 py-1">Sem {b.semester}: {b.subject} — <span className={b.status === "Active" ? "text-rose-600" : "text-teal-600"}>{b.status}</span></div>
          ))}
        </Card>

        <Card title="Assessments" icon={BookOpen}>
          {data.attempts.length ? data.attempts.map((a) => (
            <div key={a.id} className="flex justify-between py-1.5 border-b border-[hsl(214_32%_91%)] last:border-0 text-sm">
              <span>{a.language}</span>
              <span className="font-semibold">{a.total_score}/50 · {a.percentage}% <span className="text-xs text-slate-400">({a.proficiency_level})</span></span>
            </div>
          )) : <p className="text-sm text-slate-400">No assessments taken.</p>}
        </Card>

        <Card title="Certifications & Projects" icon={FolderGit2}>
          <p className="text-xs font-semibold uppercase text-slate-500 mb-1">Certifications</p>
          {(p.certifications || []).length ? p.certifications.map((c, i) => <div key={i} className="text-sm py-0.5">{c.name} — {c.organization}</div>) : <p className="text-xs text-slate-400">None</p>}
          <p className="text-xs font-semibold uppercase text-slate-500 mt-3 mb-1">Projects</p>
          {(p.projects || []).length ? p.projects.map((pr, i) => <div key={i} className="text-sm py-0.5">{pr.name} <span className="text-xs text-slate-400">({(pr.technologies || []).join(", ")})</span></div>) : <p className="text-xs text-slate-400">None</p>}
        </Card>

        <Card title="XAI Factors" icon={Award}>
          {pred ? (
            <>
              {(pred.positive_factors || []).map((f, i) => <ShapBar key={i} factor={f.factor} contribution={f.contribution} />)}
              {(pred.negative_factors || []).map((f, i) => <ShapBar key={i} factor={f.factor} contribution={f.contribution} />)}
            </>
          ) : <p className="text-sm text-slate-400">No prediction generated.</p>}
        </Card>
      </div>

      <Card title="Company Matches & Selections" icon={Mail}>
        <div className="grid sm:grid-cols-2 gap-2">
          {data.matches.map((m) => (
            <div key={m.id} className="border border-[hsl(214_32%_91%)] rounded-md p-3 text-sm">
              <div className="flex justify-between"><span className="font-medium">{m.company_name}</span><span className="font-semibold text-teal-600">{m.match_percent}%</span></div>
              <div className="text-xs text-slate-400 mt-1">Missing: {(m.missing_skills || []).join(", ") || "—"}</div>
            </div>
          ))}
        </div>
        {data.selections.length > 0 && (
          <div className="mt-3">
            <p className="text-xs font-semibold uppercase text-slate-500 mb-1">Selection History</p>
            {data.selections.map((s) => (
              <div key={s.id} className="text-sm py-1 flex justify-between">
                <span>{s.company_name}</span>
                <span className={`text-xs font-semibold ${s.status === "Selected" ? "text-teal-600" : s.status === "Rejected" ? "text-rose-600" : "text-amber-600"}`}>{s.status} {s.email_sent && "· emailed"}</span>
              </div>
            ))}
          </div>
        )}
      </Card>

      <Card title="Roadmap Progress" icon={BookOpen}>
        {data.roadmaps.length ? (
          <>
            <div className="w-full h-2 bg-slate-100 rounded-full mb-3"><div className="h-full bg-[hsl(217_91%_60%)] rounded-full" style={{ width: `${data.roadmaps[0].completion_pct}%` }} /></div>
            <p className="text-xs text-slate-500">{data.roadmaps[0].completion_pct}% complete · {data.roadmaps[0].target_role}</p>
          </>
        ) : <p className="text-sm text-slate-400">No roadmap.</p>}
      </Card>
    </div>
  );
}

function Card({ title, icon: Icon, children }) {
  return (
    <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5">
      <h2 className="font-display font-bold text-[hsl(222_47%_11%)] mb-3 flex items-center gap-2"><Icon className="w-4 h-4 text-[hsl(217_91%_60%)]" /> {title}</h2>
      {children}
    </div>
  );
}
function Row({ k, v }) {
  return <div className="flex justify-between py-1.5 text-sm border-b border-[hsl(214_32%_91%)] last:border-0"><span className="text-slate-500">{k}</span><span className="font-medium">{v}</span></div>;
}