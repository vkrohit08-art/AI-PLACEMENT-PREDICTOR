const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import ProbabilityRing from "@/components/ProbabilityRing";
import ShapBar from "@/components/ShapBar";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { readinessCategory, computeMatch, studentSkillSet } from "@/lib/employability";
import { Sparkles, Target, AlertCircle, Lightbulb, Map } from "lucide-react";

export default function Prediction() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [attempts, setAttempts] = useState([]);
  const [prediction, setPrediction] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [p, a, pred] = await Promise.all([
          db.entities.StudentProfile.filter({ created_by_id: user.id }, "-created_date", 1),
          db.entities.AssessmentAttempt.filter({ created_by_id: user.id, status: "completed" }, "-completed_at", 50),
          db.entities.PlacementPrediction.filter({ created_by_id: user.id }, "-created_date", 1),
        ]);
        setProfile(p[0] || null);
        setAttempts(a || []);
        setPrediction(pred[0] || null);
      } finally {
        setLoading(false);
      }
    })();
  }, [user?.id]);

  const generate = async () => {
    if (!profile) { toast({ title: "Complete your profile first", variant: "destructive" }); return; }
    setGenerating(true);
    try {
      const res = await db.functions.invoke("predictPlacement", {
        profile, attempts, targetRole: profile.target_role || "Software Developer"
      });
      const data = res.data;
      if (!data || data.error) throw new Error(data?.error || "Prediction failed");

      const saved = await db.entities.PlacementPrediction.create({
        probability: data.probability,
        readiness_category: data.readiness_category,
        role_readiness: data.role_readiness || [],
        positive_factors: data.positive_factors || [],
        negative_factors: data.negative_factors || [],
        skill_gaps: data.skill_gaps || [],
        recommended_skills: data.recommended_skills || [],
        insights: data.insights || [],
        generated_at: new Date().toISOString(),
      });
      setPrediction(saved);

      // Save roadmap (replace any existing active roadmap)
      if (data.roadmap?.length) {
        await db.entities.Roadmap.deleteMany({ created_by_id: user.id, status: "Active" });
        await db.entities.Roadmap.create({
          target_role: profile.target_role || "Software Developer",
          tasks: data.roadmap.map((t) => ({
            skill: t.skill, priority: t.priority, description: t.description,
            practice_activity: t.practice_activity || "", project_task: t.project_task || "",
            target_date: "", status: "Not Started"
          })),
          completion_pct: 0, status: "Active",
        });
      }

      // Compute company matches
      const companies = await db.entities.Company.list(50);
      const skills = studentSkillSet(profile, attempts);
      if (companies.length) {
        await db.entities.CompanyMatch.deleteMany({ created_by_id: user.id });
        const matches = companies.map((c) => {
          const m = computeMatch(skills, c.skills);
          return {
            student_id: user.id, student_name: profile.full_name,
            company_id: c.id, company_name: c.name,
            match_percent: m.percent, matched_skills: m.matched, missing_skills: m.missing,
            eligible: (profile.active_backlogs || 0) <= (c.max_active_backlogs || 0),
          };
        });
        await db.entities.CompanyMatch.bulkCreate(matches);
      }

      toast({ title: "Prediction generated", description: `Placement probability: ${Math.round(data.probability)}%` });
    } catch (e) {
      toast({ title: "Prediction failed", description: e.message, variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(217_91%_60%)] rounded-full animate-spin" /></div>;

  if (!profile) {
    return <div className="max-w-md mx-auto mt-12 bg-white border border-[hsl(214_32%_91%)] rounded-lg p-8 text-center">
      <p className="text-sm text-slate-500 mb-4">Complete your profile to generate a placement prediction.</p>
      <Button onClick={() => navigate("/profile")} className="bg-[hsl(217_91%_60%)]">Go to Profile</Button>
    </div>;
  }

  if (!prediction) {
    return (
      <div className="max-w-md mx-auto mt-12 bg-white border border-[hsl(214_32%_91%)] rounded-lg p-8 text-center">
        <Sparkles className="w-10 h-10 text-[hsl(217_91%_60%)] mx-auto mb-3" />
        <h1 className="font-display text-xl font-bold mb-2">Generate Your Prediction</h1>
        <p className="text-sm text-slate-500 mb-6">The AI analyzes your academics, backlogs, certifications, projects, and assessment scores to predict placement probability with explainable factors.</p>
        <Button onClick={generate} disabled={generating} className="bg-[hsl(217_91%_60%)]">
          <Sparkles className="w-4 h-4 mr-2" /> {generating ? "Analyzing..." : "Generate Prediction"}
        </Button>
      </div>
    );
  }

  const prob = prediction.probability;
  const pos = prediction.positive_factors || [];
  const neg = prediction.negative_factors || [];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold text-[hsl(222_47%_11%)]">Placement Prediction</h1>
        <Button onClick={generate} disabled={generating} variant="outline">
          <Sparkles className="w-4 h-4 mr-2" /> {generating ? "Re-analyzing..." : "Reassess"}
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-4">
        <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-6 flex flex-col items-center justify-center">
          <ProbabilityRing value={prob} size={170} label={prediction.readiness_category} />
          <p className="text-xs text-slate-500 mt-3">Generated {new Date(prediction.generated_at).toLocaleDateString()}</p>
        </div>

        <div className="lg:col-span-2 bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5">
          <h2 className="font-display text-lg font-bold mb-3 flex items-center gap-2"><Target className="w-5 h-5 text-[hsl(217_91%_60%)]" /> Role-Specific Readiness</h2>
          <div className="space-y-2">
            {(prediction.role_readiness || []).map((r, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="w-40 text-sm text-slate-600 truncate">{r.role}</span>
                <div className="flex-1 h-2 bg-slate-100 rounded-full">
                  <div className="h-full rounded-full" style={{ width: `${r.readiness}%`, backgroundColor: r.readiness >= 60 ? "hsl(173 80% 40%)" : "hsl(38 92% 50%)" }} />
                </div>
                <span className="w-12 text-right text-sm font-semibold">{Math.round(r.readiness)}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5">
          <h2 className="font-display text-lg font-bold mb-3">XAI Factor Contributions</h2>
          <p className="text-xs font-semibold uppercase tracking-wider text-teal-600 mb-1">Positive Drivers</p>
          {pos.map((f, i) => <ShapBar key={i} factor={f.factor} contribution={f.contribution} />)}
          <p className="text-xs font-semibold uppercase tracking-wider text-rose-500 mt-3 mb-1">Risk Factors</p>
          {neg.map((f, i) => <ShapBar key={i} factor={f.factor} contribution={f.contribution} />)}
        </div>

        <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5">
          <h2 className="font-display text-lg font-bold mb-3 flex items-center gap-2"><AlertCircle className="w-5 h-5 text-rose-500" /> Skill Gaps</h2>
          <div className="space-y-2">
            {(prediction.skill_gaps || []).map((g, i) => (
              <div key={i} className="flex items-center justify-between border border-[hsl(214_32%_91%)] rounded-md px-3 py-2">
                <span className="text-sm font-medium">{g.skill}</span>
                <span className={`text-xs font-semibold px-2 py-0.5 rounded ${g.priority === "High" ? "bg-rose-50 text-rose-600" : g.priority === "Medium" ? "bg-amber-50 text-amber-600" : "bg-slate-100 text-slate-600"}`}>{g.priority}</span>
              </div>
            ))}
            {!prediction.skill_gaps?.length && <p className="text-sm text-slate-400">No significant gaps detected.</p>}
          </div>
        </div>
      </div>

      {(prediction.insights || []).length > 0 && (
        <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5">
          <h2 className="font-display text-lg font-bold mb-3 flex items-center gap-2"><Lightbulb className="w-5 h-5 text-amber-500" /> AI Insights</h2>
          <ul className="space-y-2">
            {prediction.insights.map((ins, i) => <li key={i} className="text-sm text-slate-600 flex gap-2"><span className="text-[hsl(217_91%_60%)]">•</span> {ins}</li>)}
          </ul>
        </div>
      )}

      <div className="flex gap-3">
        <Button onClick={() => navigate("/roadmap")} className="bg-[hsl(217_91%_60%)]"><Map className="w-4 h-4 mr-2" /> View Roadmap</Button>
        <Button onClick={() => navigate("/companies")} variant="outline">See Company Matches</Button>
      </div>
    </div>
  );
}