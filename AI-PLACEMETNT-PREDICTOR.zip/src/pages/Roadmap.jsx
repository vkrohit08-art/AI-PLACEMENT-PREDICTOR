const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";
import { Map, CheckCircle2, Circle, Clock, Sparkles } from "lucide-react";

const STATUSES = ["Not Started", "In Progress", "Completed"];

export default function Roadmap() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [roadmap, setRoadmap] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const r = await db.entities.Roadmap.filter({ created_by_id: user.id, status: "Active" }, "-created_date", 1);
        setRoadmap(r[0] || null);
      } finally {
        setLoading(false);
      }
    })();
  }, [user?.id]);

  const updateTask = async (idx, status) => {
    if (!roadmap) return;
    const tasks = [...roadmap.tasks];
    tasks[idx] = { ...tasks[idx], status };
    const completed = tasks.filter((t) => t.status === "Completed").length;
    const pct = Math.round((completed / tasks.length) * 100);
    const updated = await db.entities.Roadmap.update(roadmap.id, { tasks, completion_pct: pct, status: pct === 100 ? "Completed" : "Active" });
    setRoadmap(updated);
    if (pct === 100) toast({ title: "Roadmap complete!", description: "Time to reassess your placement probability." });
  };

  if (loading) return <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(217_91%_60%)] rounded-full animate-spin" /></div>;

  if (!roadmap) {
    return (
      <div className="max-w-md mx-auto mt-12 bg-white border border-[hsl(214_32%_91%)] rounded-lg p-8 text-center">
        <Map className="w-10 h-10 text-slate-300 mx-auto mb-3" />
        <p className="text-sm text-slate-500 mb-4">No roadmap yet. Generate a placement prediction to get your personalized improvement plan.</p>
        <Button onClick={() => navigate("/prediction")} className="bg-[hsl(217_91%_60%)]"><Sparkles className="w-4 h-4 mr-2" /> Generate Prediction</Button>
      </div>
    );
  }

  const pct = roadmap.completion_pct || 0;

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-5">
        <div className="flex items-center justify-between mb-2">
          <div>
            <h1 className="font-display text-xl font-bold text-[hsl(222_47%_11%)]">Your Roadmap</h1>
            <p className="text-xs text-slate-500">Target role: {roadmap.target_role}</p>
          </div>
          <span className="font-display text-3xl font-bold text-[hsl(217_91%_60%)]">{pct}%</span>
        </div>
        <div className="w-full h-2 bg-slate-100 rounded-full">
          <div className="h-full bg-[hsl(217_91%_60%)] rounded-full transition-all" style={{ width: `${pct}%` }} />
        </div>
      </div>

      <div className="space-y-3">
        {roadmap.tasks.map((t, i) => (
          <div key={i} className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-4">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-2">
                {t.status === "Completed" ? <CheckCircle2 className="w-5 h-5 text-teal-500 mt-0.5" />
                  : t.status === "In Progress" ? <Clock className="w-5 h-5 text-amber-500 mt-0.5" />
                  : <Circle className="w-5 h-5 text-slate-300 mt-0.5" />}
                <div>
                  <p className="font-semibold text-sm text-[hsl(222_47%_11%)]">{t.skill}</p>
                  <p className="text-xs text-slate-500 mt-0.5">{t.description}</p>
                  {t.practice_activity && <p className="text-xs text-slate-400 mt-1">Practice: {t.practice_activity}</p>}
                  {t.project_task && <p className="text-xs text-slate-400">Project: {t.project_task}</p>}
                </div>
              </div>
              <span className={`text-[0.65rem] font-semibold px-2 py-0.5 rounded whitespace-nowrap ${t.priority === "High" ? "bg-rose-50 text-rose-600" : t.priority === "Medium" ? "bg-amber-50 text-amber-600" : "bg-slate-100 text-slate-600"}`}>{t.priority}</span>
            </div>
            <div className="flex gap-1 mt-3">
              {STATUSES.map((s) => (
                <button key={s} onClick={() => updateTask(i, s)}
                  className={`text-xs px-2.5 py-1 rounded font-medium ${t.status === s ? "bg-[hsl(217_91%_60%)] text-white" : "bg-slate-100 text-slate-600"}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      {pct === 100 && (
        <div className="bg-teal-50 border border-teal-200 rounded-lg p-4 text-center">
          <CheckCircle2 className="w-8 h-8 text-teal-600 mx-auto mb-2" />
          <p className="text-sm font-semibold text-teal-800 mb-3">Roadmap complete! Reassess to update your placement probability.</p>
          <Button onClick={() => navigate("/prediction")} className="bg-teal-600"><Sparkles className="w-4 h-4 mr-2" /> Reassess Now</Button>
        </div>
      )}
    </div>
  );
}