const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect, useRef } from "react";
import { useAuth } from "@/lib/AuthContext";

import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/components/ui/use-toast";
import { proficiencyFromPercentage } from "@/lib/employability";
import { ClipboardCheck, Clock, AlertTriangle, CheckCircle2, XCircle, Play } from "lucide-react";

const CREDITS = { Easy: 3, Intermediate: 6, Hard: 8.5 };

export default function Assessment() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [profile, setProfile] = useState(null);
  const [attempts, setAttempts] = useState([]);
  const [active, setActive] = useState(null); // { language, questions, answers, startedAt }
  const [violations, setViolations] = useState([]);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);

  useEffect(() => {
    (async () => {
      try {
        const [p, a] = await Promise.all([
          db.entities.StudentProfile.filter({ created_by_id: user.id }, "-created_date", 1),
          db.entities.AssessmentAttempt.filter({ created_by_id: user.id, status: "completed" }, "-completed_at", 50),
        ]);
        setProfile(p[0] || null);
        setAttempts(a || []);
      } finally {
        setLoading(false);
      }
    })();
  }, [user?.id]);

  // Proctoring
  useEffect(() => {
    if (!active) return;
    const flag = (type) => {
      setViolations((v) => {
        const next = [...v, { type, time: new Date().toISOString() }];
        if (next.length >= 3) {
          toast({ title: "Auto-submitting", description: "Proctoring violation threshold reached.", variant: "destructive" });
          setTimeout(() => submitAssessment(true), 500);
        }
        return next;
      });
    };
    const onVis = () => { if (document.hidden) flag("Tab switch / window blur"); };
    const onCopy = (e) => { e.preventDefault(); flag("Copy attempt"); };
    const onPaste = (e) => { e.preventDefault(); flag("Paste attempt"); };
    const onBlur = () => flag("Window lost focus");
    document.addEventListener("visibilitychange", onVis);
    document.addEventListener("copy", onCopy);
    document.addEventListener("paste", onPaste);
    window.addEventListener("blur", onBlur);
    return () => {
      document.removeEventListener("visibilitychange", onVis);
      document.removeEventListener("copy", onCopy);
      document.removeEventListener("paste", onPaste);
      window.removeEventListener("blur", onBlur);
    };
  }, [active]);

  const startAssessment = async (language) => {
    setGenerating(true);
    try {
      const res = await db.functions.invoke("generateAssessment", { language });
      const questions = res.data?.questions || [];
      if (!questions.length) throw new Error("No questions generated");
      setActive({ language, questions, answers: {}, startedAt: Date.now() });
      setResult(null);
      setViolations([]);
    } catch (e) {
      toast({ title: "Could not start assessment", description: e.message, variant: "destructive" });
    } finally {
      setGenerating(false);
    }
  };

  const setAnswer = (qId, value) => setActive((a) => ({ ...a, answers: { ...a.answers, [qId]: value } }));

  const evaluateCode = (studentCode, reference) => {
    if (!studentCode || !studentCode.trim()) return false;
    if (!reference) return true;
    const tokens = (s) => s.toLowerCase().match(/[a-z_]+/g) || [];
    const refTokens = new Set(tokens(reference));
    const stuTokens = tokens(studentCode);
    if (refTokens.size === 0) return stuTokens.length > 5;
    const overlap = stuTokens.filter((t) => refTokens.has(t)).length;
    return overlap / refTokens.size >= 0.6;
  };

  const submitAssessment = async (autoFlagged = false) => {
    if (!active || submitting) return;
    setSubmitting(true);
    let easy = 0, inter = 0, hard = 0, correct = 0, incorrect = 0;
    active.questions.forEach((q) => {
      const ans = active.answers[q.id];
      let isCorrect = false;
      if (q.type === "mcq") {
        isCorrect = ans && ans === q.correct_answer;
      } else {
        isCorrect = evaluateCode(ans, q.correct_answer);
      }
      if (isCorrect) {
        correct++;
        if (q.level === "Easy") easy += CREDITS.Easy;
        else if (q.level === "Intermediate") inter += CREDITS.Intermediate;
        else hard += CREDITS.Hard;
      } else {
        incorrect++;
      }
    });
    const total = +(easy + inter + hard).toFixed(1);
    const pct = Math.round((total / 50) * 100);
    const timeTaken = Math.round((Date.now() - active.startedAt) / 1000);
    const proctorStatus = autoFlagged || violations.length >= 3 ? "Suspicious" : violations.length > 0 ? "Warnings" : "Clean";

    try {
      const saved = await db.entities.AssessmentAttempt.create({
        language: active.language,
        questions: active.questions,
        answers: active.answers,
        easy_score: easy, intermediate_score: inter, hard_score: hard,
        total_score: total, max_score: 50, percentage: pct,
        proficiency_level: proficiencyFromPercentage(pct),
        correct_count: correct, incorrect_count: incorrect,
        time_taken_seconds: timeTaken,
        proctoring_violations: violations,
        proctoring_status: proctorStatus,
        status: autoFlagged ? "flagged" : "completed",
        started_at: new Date(active.startedAt).toISOString(),
        completed_at: new Date().toISOString(),
      });
      setAttempts((a) => [saved, ...a]);
      setResult({ language: active.language, easy, inter, hard, total, pct, correct, incorrect, timeTaken, proctorStatus, proficiency: proficiencyFromPercentage(pct) });
      setActive(null);
      setViolations([]);
    } catch (e) {
      toast({ title: "Submit failed", description: e.message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="flex justify-center py-20"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(217_91%_60%)] rounded-full animate-spin" /></div>;

  if (!profile) {
    return <Empty msg="Complete your profile and select programming languages to take assessments." cta="Go to Profile" to="/profile" />;
  }

  const langs = profile.programming_languages || [];

  if (result) {
    return <ResultView result={result} onDone={() => setResult(null)} />;
  }

  if (active) {
    return (
      <div className="max-w-3xl mx-auto space-y-4 pb-24">
        <div className="flex items-center justify-between bg-white border border-[hsl(214_32%_91%)] rounded-lg p-4 sticky top-2 z-10">
          <div>
            <h1 className="font-display text-lg font-bold text-[hsl(222_47%_11%)]">{active.language} Assessment</h1>
            <p className="text-xs text-slate-500">{active.questions.length} questions · 50 marks</p>
          </div>
          <div className="flex items-center gap-3">
            {violations.length > 0 && (
              <span className="flex items-center gap-1 text-xs font-semibold text-amber-600 bg-amber-50 px-2 py-1 rounded">
                <AlertTriangle className="w-3 h-3" /> {violations.length} violation{violations.length !== 1 ? "s" : ""}
              </span>
            )}
            <Button onClick={() => submitAssessment()} disabled={submitting} className="bg-[hsl(217_91%_60%)]">
              {submitting ? "Submitting..." : "Submit Assessment"}
            </Button>
          </div>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-md p-3 text-xs text-amber-800">
          Proctoring is active. Tab switching, copying, pasting, or losing window focus are recorded. Three violations auto-submit and flag the attempt.
        </div>

        {active.questions.map((q, idx) => (
          <div key={q.id} className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-4">
            <div className="flex items-start justify-between gap-2 mb-2">
              <p className="text-sm font-medium text-[hsl(222_47%_11%)]"><span className="text-slate-400">Q{idx + 1}.</span> {q.question}</p>
              <span className="text-[0.65rem] font-semibold uppercase px-2 py-0.5 rounded bg-slate-100 text-slate-600 whitespace-nowrap">
                {q.level} · {CREDITS[q.level]} pts
              </span>
            </div>
            {q.type === "mcq" ? (
              <div className="space-y-2">
                {(q.options || []).map((opt) => (
                  <label key={opt} className="flex items-center gap-2 text-sm cursor-pointer p-2 rounded hover:bg-slate-50">
                    <input type="radio" name={`q-${q.id}`} checked={active.answers[q.id] === opt} onChange={() => setAnswer(q.id, opt)} className="accent-[hsl(217_91%_60%)]" />
                    {opt}
                  </label>
                ))}
              </div>
            ) : (
              <Textarea
                placeholder={`Write your ${active.language} code here...`}
                value={active.answers[q.id] || ""}
                onChange={(e) => setAnswer(q.id, e.target.value)}
                rows={8}
                className="font-mono text-sm"
              />
            )}
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-4">
      <div>
        <h1 className="font-display text-2xl font-bold text-[hsl(222_47%_11%)]">Programming Assessments</h1>
        <p className="text-sm text-slate-500">Take a 10-question assessment for each selected language. 5 Easy (3pts), 3 Intermediate (6pts), 2 Hard (8.5pts) — total 50.</p>
      </div>

      {langs.length === 0 && (
        <Empty msg="No programming languages selected. Add them in your profile." cta="Edit Profile" to="/profile" />
      )}

      <div className="space-y-3">
        {langs.map((lang) => {
          const taken = attempts.filter((a) => a.language === lang);
          const best = taken.length ? Math.max(...taken.map((a) => a.total_score)) : null;
          return (
            <div key={lang} className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-4 flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-[hsl(222_47%_11%)]">{lang}</h3>
                {best !== null ? (
                  <p className="text-xs text-slate-500">Best score: <span className="font-semibold text-teal-600">{best}/50</span> · {taken.length} attempt{taken.length !== 1 ? "s" : ""}</p>
                ) : (
                  <p className="text-xs text-slate-400">Not attempted</p>
                )}
              </div>
              <Button onClick={() => startAssessment(lang)} disabled={generating} className="bg-[hsl(217_91%_60%)]">
                <Play className="w-4 h-4 mr-1" /> {generating ? "Preparing..." : best !== null ? "Retake" : "Start"}
              </Button>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function ResultView({ result, onDone }) {
  const r = result;
  return (
    <div className="max-w-2xl mx-auto space-y-4">
      <div className="bg-white border border-[hsl(214_32%_91%)] rounded-lg p-6">
        <div className="flex items-center gap-2 mb-1">
          <ClipboardCheck className="w-5 h-5 text-[hsl(217_91%_60%)]" />
          <h1 className="font-display text-xl font-bold text-[hsl(222_47%_11%)]">{r.language} Assessment Result</h1>
        </div>
        <p className="font-display text-4xl font-extrabold text-[hsl(222_47%_11%)] mt-3">{r.total}<span className="text-lg text-slate-400">/50</span></p>
        <p className="text-sm text-slate-500">Performance: <span className="font-semibold text-[hsl(222_47%_11%)]">{r.pct}%</span> · Proficiency: <span className="font-semibold text-teal-600">{r.proficiency}</span></p>

        <div className="grid grid-cols-3 gap-3 mt-5">
          <ScoreCell label="Easy" value={`${r.easy}/15`} />
          <ScoreCell label="Intermediate" value={`${r.inter}/18`} />
          <ScoreCell label="Hard" value={`${r.hard}/17`} />
        </div>
        <div className="grid grid-cols-2 gap-3 mt-3">
          <Stat label="Correct" value={r.correct} icon={CheckCircle2} tone="teal" />
          <Stat label="Incorrect" value={r.incorrect} icon={XCircle} tone="rose" />
          <Stat label="Time" value={`${Math.floor(r.timeTaken / 60)}m ${r.timeTaken % 60}s`} icon={Clock} />
          <Stat label="Proctoring" value={r.proctorStatus} icon={AlertTriangle} tone={r.proctorStatus === "Clean" ? "teal" : "amber"} />
        </div>
      </div>
      <Button onClick={onDone} className="bg-[hsl(217_91%_60%)]">Back to Assessments</Button>
    </div>
  );
}
function ScoreCell({ label, value }) {
  return <div className="border border-[hsl(214_32%_91%)] rounded-md p-3 text-center"><p className="text-[0.65rem] uppercase tracking-wider text-slate-500">{label}</p><p className="font-display font-bold text-lg">{value}</p></div>;
}
function Stat({ label, value, icon: Icon, tone }) {
  const c = tone === "teal" ? "text-teal-600" : tone === "rose" ? "text-rose-500" : "text-amber-600";
  return <div className="border border-[hsl(214_32%_91%)] rounded-md p-3 flex items-center gap-2"><Icon className={`w-4 h-4 ${c}`} /><div><p className="text-[0.65rem] uppercase tracking-wider text-slate-500">{label}</p><p className="text-sm font-semibold">{value}</p></div></div>;
}
function Empty({ msg, cta, to }) {
  return (
    <div className="max-w-md mx-auto mt-12 bg-white border border-[hsl(214_32%_91%)] rounded-lg p-8 text-center">
      <ClipboardCheck className="w-10 h-10 text-slate-300 mx-auto mb-3" />
      <p className="text-sm text-slate-500 mb-4">{msg}</p>
      <a href={to} className="text-sm font-semibold text-[hsl(217_91%_60%)]">{cta} →</a>
    </div>
  );
}